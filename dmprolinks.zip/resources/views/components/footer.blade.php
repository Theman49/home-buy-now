<footer>
    <p class="text-center">DM pro &copy; 2022 | made with love</p>
</footer>