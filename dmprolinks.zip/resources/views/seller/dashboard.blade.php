@extends('../layout/dashboardSeller')
@section('main')
    <div class="alert alert-primary my-5" role="alert">
       <h1>Selamat datang</h1> 
    </div>
@endsection