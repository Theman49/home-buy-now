<?php $__env->startSection('main'); ?>
    <?php if(session()->has('success')): ?>
        <div class="alert alert-success my-5" role="alert">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <a href="/seller/insert" class="btn btn-primary mb-3">Tambah Rumah</a>
    <table class="table table-striped table-hover">
        <thead>
            <tr>
            <th scope="col">#</th>
            <th scope="col">Nama Rumah</th>
            <th scope="col">Tipe Rumah</th>
            <th scope="col">Lokasi</th>
            <th scope="col">Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $number = 0; ?>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $number += 1 ?>
            <tr>
                <th scope="row"><?php echo e($number); ?></th>
                <td><?php echo e($item->nama_object); ?></td>
                <td><?php echo e($item->jenis_rumah); ?></td>
                <td><?php echo e($item->nama_lokasi); ?></td>
                <td>
                    <a href="/seller/preview/<?php echo e($item->id_house); ?>" class="col badge bg-info"><span data-feather="eye"></span></a>
                    <a href="/seller/<?php echo e($item->id_house); ?>/edit" class="col badge bg-warning"><span data-feather="edit"></span></a>
                    <form action="/dashboard/delete" method="post" class="d-inline">
                        <input type="text" name="id" class="d-none" value="<?php echo e($item->id_house); ?>">
                        <input type="text" name="jenis_rumah" class="d-none" value="<?php echo e($item->jenis_rumah); ?>">
                        <?php echo csrf_field(); ?>
                        <button class="border-0 col badge bg-danger" onclick="return confirm('Anda yakin ingin menghapus ' + '<?php echo e($item->nama_object); ?>' + ' ?')"><span data-feather="x-circle"></span></button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('../layout/dashboardSeller', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/cakdeny49/Documents/My Project/LARAVEL/HOME-BUY-NOW-app/resources/views/seller/posts.blade.php ENDPATH**/ ?>