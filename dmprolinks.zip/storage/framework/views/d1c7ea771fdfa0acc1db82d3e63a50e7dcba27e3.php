<footer>
    <p class="text-center">DM pro &copy; 2022 | made with love</p>
</footer><?php /**PATH /home/cakdeny49/Documents/My Project/LARAVEL/HOME-BUY-NOW-app/resources/views////components/footer.blade.php ENDPATH**/ ?>