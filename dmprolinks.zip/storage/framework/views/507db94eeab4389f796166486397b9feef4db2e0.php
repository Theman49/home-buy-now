<?php $__env->startSection('main'); ?>
    <div class="alert alert-primary my-5" role="alert">
       <h1>Selamat datang</h1> 
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('../layout/dashboardSeller', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/cakdeny49/Documents/My Project/LARAVEL/HOME-BUY-NOW-app/resources/views/seller/dashboard.blade.php ENDPATH**/ ?>