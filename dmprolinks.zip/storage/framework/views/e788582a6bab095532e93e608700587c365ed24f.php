<?php $__env->startSection('main'); ?>
    <a href="/seller/primary/insert" class="btn btn-primary mb-3">Tambah Rumah</a>
    <table class="table table-striped table-hover">
        <thead>
            <tr>
            <th scope="col">#</th>
            <th scope="col">Nama Rumah</th>
            <th scope="col">Lokasi</th>
            <th scope="col">Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $number = 0; ?>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $number += 1 ?>
            <tr>
                <th scope="row"><?php echo e($number); ?></th>
                <td><?php echo e($item->nama_object); ?></td>
                <td><?php echo e($item->nama_lokasi); ?></td>
                <td>
                    <a href="/seller/primary/<?php echo e($item->id_home); ?>" class="col badge bg-info"><span data-feather="eye"></span></a>
                    <a href="/seller/primary/<?php echo e($item->id_home); ?>/edit" class="col badge bg-warning"><span data-feather="edit"></span></a>
                    <form action="/seller/primary/<?php echo e($item->id_home); ?>" method="post" class="d-inline">
                        <?php echo method_field('delete'); ?>
                        <?php echo csrf_field(); ?>
                        <button class="border-0 col badge bg-danger" onclick="return confirm('Anda yakin ingin menghapus ' + '<?php echo e($item->nama_object); ?>' + ' ?')"><span data-feather="x-circle"></span></button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('../layout/dashboardSeller', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/cakdeny49/Documents/My Project/LARAVEL/HOME-BUY-NOW-app/resources/views/seller/primary.blade.php ENDPATH**/ ?>