<?php $__env->startSection('main'); ?>
<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<form action="/dashboard/edit" method="POST" enctype="multipart/form-data">
  <?php echo csrf_field(); ?>
  <div class="mb-3">
    <label for="namaObject" class="form-label">Nama Rumah</label>
    <input type="text" class="form-control <?php $__errorArgs = ['nama_object'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="namaObject" aria-describedby="emailHelp" name="nama_object" value="<?php echo e(old('nama_object', $item->nama_object)); ?>" autofocus>
    <?php $__errorArgs = ['nama_object'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
      <p class="text-danger"><?php echo e($message); ?></p>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  </div>
  <div class="mb-3">
    <label for="gambarExist" class="form-label">Gambar yang Sudah Ada</label>
    <div class="row">
      <?php $__currentLoopData = $gambar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
          $url = "$item->jenis_rumah/$item->id_house/$image->item";
        ?>
        <div class="col-sm-3 col-md-3 mb-3" id="gambar<?php echo e($image->no); ?>">
          <label onclick="deleteGambar('<?php echo e($image->no); ?>')" style="cursor: pointer">x</label>
          <img src="<?php echo e(asset('/storage/public/'.$url)); ?>" alt="" style="height: 100px; width: 150px">
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>
  <input class="d-none" type="text" id="idHome" name="id_house" value="<?php echo e($item->id_house); ?>">
  <input class="d-none" type="text" id="deletedGambar" name="deletedGambar">
  <input class="d-none" type="text" id="tipeRumah" name="tipe_rumah" value="<?php echo e($item->jenis_rumah); ?>">
  <div class="mb-3">
    <label for="gambar" class="form-label">Gambar</label>
    <input type="file" multiple class="form-control <?php $__errorArgs = ['gambar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="gambar" aria-describedby="emailHelp" name="item[]" value="<?php echo e(old('item')); ?>" autofocus>
    <?php $__errorArgs = ['item'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
      <p class="text-danger"><?php echo e($message); ?></p>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  </div>
  <div class="row">
    <div class="col col-sm-12 col-md-6">
      <div class="mb-3">
        <label for="" class="form-label">Jenis Rumah : </label><br>
        <input type="radio" value="primary" id="kategori1" name="jenis_rumah" <?php echo e($item->jenis_rumah == "primary" ? "checked" : ""); ?>><label class="mx-1" for="kategori1">Primary</label>
        <input type="radio" value="secondary" id="kategori2" name="jenis_rumah" <?php echo e($item->jenis_rumah == "secondary" ? "checked" : ""); ?>><label class="mx-1" for="kategori2">Secondary</label>
      </div>
      <div class="mb-3">
        <label for="" class="form-label">Lokasi Rumah : </label><br>
        <select class="form-select w-75" aria-label="Default select example" name="id_lokasi" id="lokasi">
          <?php $__currentLoopData = $lokasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lok): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($lok->id_lokasi); ?>" <?php echo e($item->id_lokasi == $lok->id_lokasi ? "selected" : ""); ?>><?php echo e(ucfirst($lok->nama_lokasi)); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>
      <div class="mb-3">
        <label for="jumlahLantai" class="form-label">Jumlah Lantai</label>
        <input type="number" min=1 class="form-control  w-75 <?php $__errorArgs = ['jumlah_lantai'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="jumlahLantai" aria-describedby="emailHelp" name="jumlah_lantai" value="<?php echo e(old('jumlah_lantai', $item->jumlah_lantai)); ?>" autofocus>
        <?php $__errorArgs = ['jumlah_lantai'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <p class="text-danger"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>
      <div class="mb-3">
        <label for="harga" class="form-label">Harga</label>
        <input type="number" min=1 class="form-control  w-75 <?php $__errorArgs = ['harga'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="harga" aria-describedby="emailHelp" name="harga" value="<?php echo e(old('harga', $item->harga)); ?>" autofocus>
        <?php $__errorArgs = ['harga'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <p class="text-danger"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>
      <div class="mb-3">
        <label for="luasTanah" class="form-label">Luas Tanah</label>
        <input type="number" min=1 class="form-control  w-75 <?php $__errorArgs = ['luas_tanah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="luasTanah" aria-describedby="emailHelp" name="luas_tanah" value="<?php echo e(old('luas_tanah', $item->luas_tanah)); ?>" autofocus>
        <?php $__errorArgs = ['luas_tanah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <p class="text-danger"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>

    </div>

    <div class="col col-sm-12 col-md-6">
      <div class="mb-3">
        <label for="luasBangunan" class="form-label">Luas Bangunan</label>
        <input type="number" min=1 class="form-control  w-75 <?php $__errorArgs = ['luas_bangunan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="luasBangunan" aria-describedby="emailHelp" name="luas_bangunan" value="<?php echo e(old('luas_bangunan', $item->luas_bangunan)); ?>" autofocus>
        <?php $__errorArgs = ['luas_bangunan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <p class="text-danger"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>
      <div class="mb-3">
        <label for="jumlahKamarTidur" class="form-label">Jumlah Kamar Tidur</label>
        <input type="number" min=1 class="form-control  w-75 <?php $__errorArgs = ['jumlah_kamar_tidur'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="jumlahKamarTidur" aria-describedby="emailHelp" name="jumlah_kamar_tidur" value="<?php echo e(old('jumlah_kamar_tidur', $item->jumlah_kamar_tidur)); ?>" autofocus>
        <?php $__errorArgs = ['jumlah_kamar_tidur'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <p class="text-danger"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>
      <div class="mb-3">
        <label for="jumlahKamarMandi" class="form-label">Jumlah Kamar Mandi</label>
        <input type="number" min=1 class="form-control  w-75 <?php $__errorArgs = ['jumlah_kamar_tidur'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="jumlahKamarMandi" aria-describedby="emailHelp" name="jumlah_kamar_mandi" value="<?php echo e(old('jumlah_kamar_mandi', $item->jumlah_kamar_mandi)); ?>" autofocus>
        <?php $__errorArgs = ['jumlah_kamar_mandi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <p class="text-danger"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>
      <div class="mb-3">
        <label for="jumlahCarport" class="form-label">Jumlah Carport</label>
        <input type="number" min=0 class="form-control  w-75 <?php $__errorArgs = ['jumlah_carport'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="jumlahCarport" aria-describedby="emailHelp" name="jumlah_carport" value="<?php echo e(old('jumlah_carport', $item->jumlah_carport)); ?>" autofocus>
        <?php $__errorArgs = ['jumlah_carport'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <p class="text-danger"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>
      <div class="mb-3">
        <label for="tahunBangun" class="form-label">Tahun Bangun</label>
        <input type="number" min=1 class="form-control  w-75 <?php $__errorArgs = ['tahun_bangu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="tahunBangun" aria-describedby="emailHelp" name="tahun_bangun" value="<?php echo e(old('tahun_bangun', $item->tahun_bangun)); ?>" autofocus>
        <?php $__errorArgs = ['tahun_bangun'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <p class="text-danger"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>
    </div>

  </div>

  <div class="mb-3">
    <label for="deskripsi" class="form-label">Deskripsi</label>
    <?php $__errorArgs = ['deskripsi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <p class="text-danger"><?php echo e($message); ?></p>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <input id="deskripsi" type="hidden" name="deskripsi" value="<?php echo old('deskripsi', $item->deskripsi); ?>">
    <trix-editor input="deskripsi"></trix-editor>
  </div>

  <button type="submit" class="btn btn-primary">Edit Post</button>
</form>

<script>
  function deleteGambar(id){
    const getId = "gambar" + id
    let deletedGambarInput = document.getElementById('deletedGambar')
    var gambar = document.getElementById(getId)
    gambar.style.display = "none"
    deletedGambarInput.value += id + ",";
  }
</script>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('../layout/dashboardSeller', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/cakdeny49/Documents/My Project/LARAVEL/HOME-BUY-NOW-app/resources/views/seller/edit.blade.php ENDPATH**/ ?>