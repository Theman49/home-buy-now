<?php $__env->startSection('head'); ?>
<link rel="stylesheet" href="/css/buyer/home.css">
<link rel="stylesheet" href="/css/buyer/navbar.css">
<title><?php echo e($title); ?> | Home Buy Now</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('container'); ?>
<div class="container pt-4">
<?php echo $__env->make('buyer/components/navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <a href="javascript:history.go(-1)" class="back btn btn-warning mt-4">Back</a>

    <p class="path mb-3"><a href="/beranda">beranda</a> / <a href="/<?php echo e($item->jenis_rumah); ?>"><?php echo e($item->jenis_rumah); ?></a> / <a href="/search/<?php echo e($item->nama_lokasi); ?>"><?php echo e($item->nama_lokasi); ?></a> / <span class="color-light-blue-1"><?php echo e($item->nama_object); ?></p>

    <div class="d-flex justify-content-between">  
    
        <div id="carouselImage" class="carousel slide" data-bs-ride="true">
            <div class="carousel-indicators">
                <?php
                    $no = 0;
                    foreach($images as $image){
                        ?>
                            <button type="button" data-bs-target="#carouselImage" data-bs-slide-to="<?=$no?>" class="active" <?=$no == 0 ? 'aria-current="true"' : ''?> aria-label="Slide <?=$no+1?>"></button>
                        <?php
                        $no++;
                    }
                ?>
            </div>
            <div class="carousel-inner">
                <?php
                    $no = 0;
                    foreach($images as $image){
                        $url = "$item->jenis_rumah/$item->id_house/$image->item";
                        ?>
                            <div class="carousel-item <?=$no == 0 ? "active" : ""?>">
                                <img src="<?php echo e(asset('/storage/public/'.$url)); ?>" class="d-block" alt="...">
                            </div>
                        <?php
                        $no++;
                    }
                ?>
            </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#carouselImage" data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#carouselImage" data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
            </button>
        </div>

        

    </div>
    <div class="row mb-4">
            <div class="d-flex align-items-center my-3 mb-1">
                <img src="/img/lokasi.png" alt="">
                <p class="location ms-3 color-light-blue-1"><?php echo e(ucfirst($item->nama_lokasi)); ?></p>
            </div>
            <h3><?php echo e($item->nama_object); ?></h3>
    </div>

    <?php
        $harga = $item->harga;
        $formatedHarga = "";
        $index = 0;
        for($i=strlen($harga)-1;$i>=0;$i--){
            if($index % 3 == 0 && $i != strlen($harga) -1){
                $formatedHarga .= ".";
            }            
            $formatedHarga .= $harga[$i];
            $index+=1;
        }
        $formatedHarga = strrev($formatedHarga)
    ?>

    <div class="row description">
        <div class="col-sm-12 col-md-8">
            <p>Luas Bangunan : <?php echo e($item->luas_bangunan); ?>m<sup>2</sup></p>
            <p>Luas Tanah : <?php echo e($item->luas_tanah); ?>m<sup>2</sup></p>
            <p>Jumlah Kamar Tidur : <?php echo e($item->jumlah_kamar_tidur); ?> Kamar Tidur</p>
            <p>Jumlah Kamar Mandi : <?php echo e($item->jumlah_kamar_mandi); ?> Kamar Mandi</p>
            <p>Jumlah Carport : <?php echo e($item->jumlah_carport); ?></p>
            <p>Tahun Bangun : <?php echo e($item->tahun_bangun); ?></p>
            <p><b>Rp <?php echo e($formatedHarga); ?>,-</b></p>

            <hr>
            <h3 class="mt-3">Description</h3>
            <div id="description-text"><?php echo $item->deskripsi; ?></div>
        </div>
        
        <div class="col-sm-12 col-md-4">
            <div class="card p-3">
                <div class="text-center">
                    <h4>Selengkapnya tentang properti ini</h4>
                    <p>Tanyakan Kebutuhanmu disini.</p>
                </div>
                <div class="p-3">
                    <div class="mb-3">
                        <input class="form-control" type="text" id="nama" placeholder="nama">
                    </div>
                    <div class="mb-3">
                        <textarea class="form-control" name="pertanyaan" id="pertanyaan" cols="30" rows="5" placeholder="tuliskan pertanyaanmu disini..."></textarea>
                    </div>
                    <div class="text-center">
                        <button class="btn bg-light-green-1 text-white d-flex align-items-center m-auto" id="kirim" onclick="generateMessage()"><img class="me-3" src="/img/whatsapp-icon.png" alt="">Kirim Pesan</button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        // https://wa.me/15551234567?text=I'm%20interested%20in%20your%20car%20for%20sale
        function generateMessage(){
            const nama = document.getElementById('nama').value;
            const pertanyaan = document.getElementById('pertanyaan').value;

            const message = "Halo!! saya " + nama + ", " + pertanyaan + "   (<?php echo e($item->jenis_rumah); ?>_<?php echo e($item->nama_object); ?>)";

            document.location.href = "https://wa.me/+6285729331669?text=" + message
        }


    </script>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <!-- <div class="d-flex justify-content-between navigation">
        <a href="/<?php echo e($section); ?>/detail/<?php echo e($prevId); ?>" class="btn btn-primary">Previous</a>
        <a href="/<?php echo e($section); ?>/detail/<?php echo e($nextId); ?>" class="btn btn-primary">Next</a>
    </div> -->
</div>
    

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('../layout/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/cakdeny49/Documents/My Project/LARAVEL/HOME-BUY-NOW-app/resources/views/buyer/detail.blade.php ENDPATH**/ ?>