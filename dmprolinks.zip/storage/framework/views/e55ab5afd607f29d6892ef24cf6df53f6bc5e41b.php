<div class="card">
    <div class="image">
        <img src="/img/primary/<?php echo e($item->id_home); ?>/1.jpg" alt="">
        <div class="title text-white">
            <p><b><?php echo e($item->nama_object); ?></b></p>
            <p><?php echo e($item->nama_lokasi); ?></p>
        </div>
    </div>

    <div class="text">
        <div>
            <div class="d-flex justify-content-between">
                <div><p>Luas Bangunan : <?php echo e($item->luas_bangunan); ?></p></div>
                <div><p>Jumlah Lantai : <?php echo e($item->jumlah_lantai); ?></p></div>
            </div>
            <div class="d-flex justify-content-between">
                <div><p>Luas Tanah : <?php echo e($item->luas_tanah); ?></p></div>
                <div><p>Jumlah Kamar : <?php echo e($item->jumlah_kamar_tidur); ?></p></div>
            </div>
        </div>        
        <?php
            $harga = $item->harga;
            $formatedHarga = "";
            $index = 0;
            for($i=strlen($harga)-1;$i>=0;$i--){
                if($index % 3 == 0 && $i != strlen($harga) -1){
                    $formatedHarga .= ".";
                }            
                $formatedHarga .= $harga[$i];
                $index+=1;
            }
            $formatedHarga = strrev($formatedHarga)
        ?>

        <div class="d-flex justify-content-between align-items-end">
            <div>
                <h4><b>Rp <?php echo e($formatedHarga); ?>,-</b></h4>
            </div>
            <div>
                <a href="/primary/detail/<?php echo e($item->id_home); ?>" class="btn btn-primary">View</a>
            </div>
        </div>
    </div>
</div><?php /**PATH /home/cakdeny49/Documents/My Project/LARAVEL/HOME-BUY-NOW-app/resources/views////buyer/components/primaryCard.blade.php ENDPATH**/ ?>