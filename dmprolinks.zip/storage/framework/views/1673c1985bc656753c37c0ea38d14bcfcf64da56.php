<div class="d-flex justify-content-start mt-5">
    <form action="/search" class="d-flex">
        <div>
            <select id="jenis" name="jenis" class="form-select form-select-lg">
                <option value="">Jenis Rumah</option>
                <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($item->id_kategori < 3): ?>
                        <option value="<?php echo e($item->nama_kategori); ?>" <?=isset($_GET['jenis']) && $_GET['jenis'] == $item->nama_kategori ? "selected" : ""?>><?php echo e(ucfirst($item->nama_kategori)); ?></option>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

        </div>
        <div>
            <select id="lokasi" name="lokasi" class="form-select form-select-lg">
                <option value="">lokasi</option>
                <?php $__currentLoopData = $lokasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lok): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($lok->id_lokasi); ?>" <?=isset($_GET['lokasi']) && $_GET['lokasi'] == $lok->id_lokasi ? "selected" : ""?>><?php echo e(ucfirst($lok->nama_lokasi)); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div>
            <select id="harga" name="harga" class="form-select form-select-lg" aria-label=".form-select-sm example">
                <option value="">harga</option>
                <?php 
                    $harga = [
                        '<= 100 Juta',
                        '100 juta - 500 juta',
                        '500 juta - 1 Miliar',
                        '1 Miliar - 3 Miliar',
                        '3 Miliar - 5 Miliar',
                        '> 5 Miliar'
                    ];
                    $i = 0;
                ?>
                <?php $__currentLoopData = $prices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $price): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($price->id_harga); ?>" <?=isset($_GET['harga']) && $_GET['harga'] == $price->id_harga ? "selected" : ""?>><?php echo e($harga[$i]); ?></option>
                    <?php $i++?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div>
            <button class="btn btn-secondary px-4 h-100 fs-5">filter</button>
        </div>
    </form>
</div><?php /**PATH /home/cakdeny49/Documents/My Project/LARAVEL/HOME-BUY-NOW-app/resources/views////buyer/components/filter.blade.php ENDPATH**/ ?>