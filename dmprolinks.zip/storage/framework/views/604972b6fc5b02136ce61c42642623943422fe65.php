<?php $__env->startSection('main'); ?>
<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <h1><?php echo e($item->nama_object); ?></h1>
    <h5><?php echo e($item->nama_lokasi); ?></h5>
    <h6><?php echo e($item->jenis_rumah); ?></h6>
    <div id="carouselImage" class="carousel slide" data-bs-ride="true">
        <div class="carousel-indicators">
            <?php
                $no = 0;
                foreach($images as $image){
                    ?>
                        <button type="button" data-bs-target="#carouselImage" data-bs-slide-to="<?=$no?>" class="active" <?=$no == 0 ? 'aria-current="true"' : ''?> aria-label="Slide <?=$no+1?>"></button>
                    <?php
                    $no++;
                }
            ?>
        </div>
        <div class="carousel-inner">
            <?php
                $no = 0;
                foreach($images as $image){
                    $url = "$item->jenis_rumah/$item->id_house/$image->item";
                    ?>
                        <div class="carousel-item <?=$no == 0 ? "active" : ""?>">
                            <img src="<?php echo e(asset('/storage/public/'.$url)); ?>" class="d-block w-100" alt="...">
                        </div>
                    <?php
                    $no++;
                }
            ?>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#carouselImage" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#carouselImage" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
        </button>
    </div>

    <?php
        $harga = $item->harga;
        $formatedHarga = "";
        $index = 0;
        for($i=strlen($harga)-1;$i>=0;$i--){
            if($index % 3 == 0 && $i != strlen($harga) -1){
                $formatedHarga .= ".";
            }            
            $formatedHarga .= $harga[$i];
            $index+=1;
        }
        $formatedHarga = strrev($formatedHarga)
    ?>

    <div>
        <p>Luas Bangunan : <?php echo e($item->luas_bangunan); ?>m<sup>2</sup></p>
        <p>Luas Tanah : <?php echo e($item->luas_tanah); ?>m<sup>2</sup></p>
        <p>Jumlah Kamar Tidur : <?php echo e($item->jumlah_kamar_tidur); ?> Kamar Tidur</p>
        <p>Jumlah Kamar Mandi : <?php echo e($item->jumlah_kamar_mandi); ?> Kamar Mandi</p>
        <p>Jumlah Carport : <?php echo e($item->jumlah_carport); ?></p>
        <p>Tahun Bangun : <?php echo e($item->tahun_bangun); ?></p>
        <p><b>Rp <?php echo e($formatedHarga); ?>,-</b></p>
        <h3>Deskripsi</h3>
        <div>
            <?php echo $item->deskripsi; ?>

        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('../layout/dashboardSeller', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/cakdeny49/Documents/My Project/LARAVEL/HOME-BUY-NOW-app/resources/views/seller/preview.blade.php ENDPATH**/ ?>