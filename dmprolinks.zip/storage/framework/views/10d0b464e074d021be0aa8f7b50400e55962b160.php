<?php $__env->startSection('head'); ?>
<link rel="stylesheet" href="/css/home.css">
<title><?php echo e($title); ?> | Home Buy Now</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('container'); ?>
    <!-- B U Y E R  -->
		<div class="center container login" id="buyer">
			<div class="row">
				<div class="col text-center status" id="statusBuyer">
					<h1 style="vertical-align:middle;">Buyer</h1>
					<div class="mb-3">
						<label>or Login as <span id="changeToSeller" class="changeTo">Seller</span></label>
					</div>
					<div class="mb-3">
						<label>Didn't have any account? <a href="/register?status=buyer">Register here</a></label>
					</div>
				</div>
				<div class="col myFormLogin" id="formBuyer">
					<form method="POST" action="/auth/submitLogin">
						<h1 class="text-center">Login</h1>
						<h6 class="text-center"  style="margin-bottom:20px">as Buyer</h6>
						<div class="mb-3">
							<!-- <label for="exampleInputEmail1" class="form-label">Email address:</label> -->
							<input type="email" class="form-control"aria-describedby="emailHelp" name="email" placeholder="Email" required>
						</div>
						<div class="mb-3">
							<!-- <label for="exampleInputPassword1" class="form-label">Password:</label> -->
							<input type="password" class="form-control pwd" name="password" placeholder="Password" required>
						</div>
						<div class="mb-3 form-check">
							<input type="checkbox" class="form-check-input cekmeout" destination=0>
							<label class="form-check-label" for="exampleCheck1">Check me out</label>
						</div>
						<input type="submit" class="btn btn-primary" name="submitLoginBuyer" value="Login" style="margin-bottom: 10px;">
						
					</form>	
				</div>
			</div>
		</div>
		
		<!-- S E L L E R -->
		<div class="center container card login" id="seller">
			<div class="row">
				<div class="col myFormLogin" id="formSeller">
					<form method="POST" action="/auth/loginSeller">
						<?php echo csrf_field(); ?>
						<h1 class="text-center">Login</h1>
						<h6 class="text-center" style="margin-bottom:20px">as Seller</h6>
						<div class="mb-3">
							<!-- <label for="exampleInputEmail1" class="form-label">Email address:</label> -->
							<input type="email" class="form-control" aria-describedby="emailHelp" name="email" placeholder="Email">
							<?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
								<p class="text-danger"><?php echo e($message); ?></p>
							<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
						</div>
						<div class="mb-3">
							<!-- <label for="exampleInputPassword1" class="form-label">Password:</label> -->
							<input type="password" class="form-control pwd" name="password" placeholder="Password">
							<?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
								<p class="text-danger"><?php echo e($message); ?></p>
							<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
						</div>
						<div class="mb-3 form-check">
							<label class="form-check-label" for="exampleCheck1">Check me out</label>
							<input type="checkbox" class="form-check-input cekmeout" destination=1>
						</div>
						<input type="submit" class="btn btn-primary" name="submitLoginSeller" value="Login" style="margin-bottom: 10px;">
						
					</form>	
				</div>
				<div class="col text-center status" id="statusSeller">
					<h1 style="vertical-align:middle;">Seller</h1>
					<div class="mb-3">
						<label>or Login as <span id="changeToBuyer" class="changeTo">Buyer</span></label>
					</div>
					<div class="mb-3">
						<label>Didn't have any account? <a href="/register?status=seller">Register here</a></label>
					</div>	
				</div>
			</div>
		</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script src="/js/home.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('../layout/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/cakdeny49/Documents/My Project/LARAVEL/HOME-BUY-NOW-app/resources/views/auth/login.blade.php ENDPATH**/ ?>