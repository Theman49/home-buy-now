<?php $__env->startSection('head'); ?>
<link rel="stylesheet" href="/css/buyer/home.css">
<link rel="stylesheet" href="/css/buyer/navbar.css">
<title><?php echo e($title); ?> | Home Buy Now</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('container'); ?>
<div class="container pt-4">
    <?php echo $__env->make('../buyer/components/navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('../buyer/components/filter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <div class="grid-container container">
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo $__env->make('../buyer/components/card', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sript'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('../layout/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/cakdeny49/Documents/My Project/LARAVEL/HOME-BUY-NOW-app/resources/views/buyer/primary.blade.php ENDPATH**/ ?>